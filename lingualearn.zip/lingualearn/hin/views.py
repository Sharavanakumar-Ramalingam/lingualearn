from django.shortcuts import render
from googletrans import Translator
from django.http import HttpResponse, JsonResponse


def hin(request):
    return render(request,"hin_main.html")

def translator(request):
    if request.method == 'POST':
        text = request.POST.get('text', '')
        src_lang = request.POST.get('language', 'en') 
        dest_lang = request.POST.get('dest_language', 'en')
        translated_text = translate(text, src_lang, dest_lang)
        return render(request, 'translator.html', {'translated_text': translated_text})
    else:
        return render(request, 'translator.html', {})

def translate(text, src, dest):
    translator = Translator()
    translated_text = translator.translate(text, src=src, dest=dest)
    return translated_text.text


import pandas as pd
from Levenshtein import distance


df = pd.read_excel("C:/Users/sharavana Kumar/OneDrive/Desktop/guvi/lingualearn/hin/Hindi.xlsx")

def correct_errors(input_text):
    corrected_text = []
    for word in input_text.split():
        min_dist = float('inf')
        corrected_word = word
        for _, row in df.iterrows():
            dist = distance(word, row['Disfluent Sentence'])
            if dist < min_dist:
                min_dist = dist
                corrected_word = row['Hindi Fluent Sentence']
        corrected_text.append(corrected_word)
    return ' '.join(corrected_text)

def hin_bot(request):
    if request.method == 'POST':
        try:
            user_input = request.POST['text']
            corrected_text = correct_errors(user_input)
            return JsonResponse({'original_text': user_input,'result': corrected_text})
        except KeyError:
            return JsonResponse({'error': 'Invalid request format.'}, status=400)
    else:
        return render(request, 'hin_bot.html')

from django.http import JsonResponse
from django.shortcuts import render, redirect
from .forms import QuestionForm, OptionForm
from .models import Question, Option

def add_question(request):
    if request.method == 'POST':
        question_form = QuestionForm(request.POST)
        option_forms = [OptionForm(request.POST, prefix=str(i)) for i in range(4)]
        if question_form.is_valid() and all([form.is_valid() for form in option_forms]):
            question = question_form.save()
            for form in option_forms:
                option = form.save(commit=False)
                option.question = question
                option.save()
            return redirect('add_question')
    else:
        question_form = QuestionForm()
        option_forms = [OptionForm(prefix=str(i)) for i in range(4)]
    return render(request, 'add_question.html', {'question_form': question_form, 'option_forms': option_forms})

def quiz_view(request):
    questions = Question.objects.all()
    return render(request, 'quiz.html', {'questions': questions})


from django.http import JsonResponse
from django.shortcuts import render, redirect
from .forms import QuestionForm, OptionForm
from .models import Question, Option

def submit_answer(request):
    if request.method == 'POST':
        correct_answers_count = 0
        total_questions = 0
        is_correct = False

        answer_id = request.POST.get('answer_id')

        question_id = request.POST.get('question_id')

        try:
            correct_option = Option.objects.get(question__id=question_id, is_correct=True)

            if answer_id == str(correct_option.id):
                is_correct = True
                correct_answers_count += 1
            total_questions += 1


            return JsonResponse({'is_correct': is_correct})

        except Option.DoesNotExist:
            return JsonResponse({'error': 'Question not found or invalid answer ID'})

    else:
        return HttpResponse("This page only supports POST requests.")



def generate_question_html(question):
    if question:
        question_html = f'<h3>{question.text}</h3>'
        options = question.option_set.all()
        for option in options:
            question_html += f'<input type="radio" name="question{question.id}" value="{option.id}">'
            question_html += f'<label>{option.text}</label><br>'
        return question_html
    else:
        return '' 



def fetch_next_question(request):
    if request.method == 'GET':
        next_question = Question.objects.order_by('?').first()
        question_html = generate_question_html(next_question)
        return JsonResponse({'question_html': question_html})

