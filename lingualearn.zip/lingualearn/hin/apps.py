from django.apps import AppConfig


class HinConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'hin'
