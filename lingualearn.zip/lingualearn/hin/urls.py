from django.urls import path
from hin import views

urlpatterns = [
    path('hin_main',views.hin,name='Hindi'),
    path('add_question/', views.add_question, name='add_question'),
    path('hin_quiz/', views.quiz_view, name='quiz_view'),
    path('fetch_next_question/', views.fetch_next_question, name='fetch_next_question'),
    path('submit_answer/', views.submit_answer, name='submit_answer'),
    path('hin_bot/',views.hin_bot,name="hin_bot"),
]