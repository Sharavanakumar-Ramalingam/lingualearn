from django.urls import path
from . import views

urlpatterns = [
    path('choose',views.home , name='choose'),
    path('signup',views.signup,name="signup"),
    path('signin',views.signin,name="signin"),
]
 