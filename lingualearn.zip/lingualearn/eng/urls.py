from django.urls import path
from eng import views

urlpatterns = [
    path('eng_main',views.eng,name='English'),
    path('translator',views.translator,name="translator"),
    path('add_question/', views.add_question, name='add_question'),
    path('eng_quiz/', views.quiz_view, name='quiz_view'),
    path('fetch_next_question/', views.fetch_next_question, name='fetch_next_question'),
    path('submit_answer/', views.submit_answer, name='submit_answer'),
    path('eng_bot/',views.eng_bot,name="eng_bot"),
]