from django.urls import path
from sans import views

urlpatterns = [
    path('sans_main',views.sans,name='Sanskrit'),
    path('add_question/', views.add_question, name='add_question'),
    path('sans_quiz/', views.quiz_view, name='quiz_view'),
    path('fetch_next_question/', views.fetch_next_question, name='fetch_next_question'),
    path('submit_answer/', views.submit_answer, name='submit_answer'),
    path('sans_bot/',views.sans_bot,name="sans_bot"),
]