from django.urls import path
from tam import views

urlpatterns = [
    path('tam_main',views.tam,name='Tamil'),
    path('add_question/', views.add_question, name='add_question'),
    path('tam_quiz/', views.quiz_view, name='quiz_view'),
    path('fetch_next_question/', views.fetch_next_question, name='fetch_next_question'),
    path('submit_answer/', views.submit_answer, name='submit_answer'),
    path('tam_bot/',views.tam_bot,name="tam_bot"),
]