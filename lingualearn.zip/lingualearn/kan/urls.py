from django.urls import path
from kan import views

urlpatterns = [
    path('kan_main',views.kan,name='kanadam'),
    path('add_question/', views.add_question, name='add_question'),
    path('kan_quiz/', views.quiz_view, name='quiz_view'),
    path('fetch_next_question/', views.fetch_next_question, name='fetch_next_question'),
    path('submit_answer/', views.submit_answer, name='submit_answer'),
    path('kan_bot/',views.kan_bot,name="kan_bot"),
]