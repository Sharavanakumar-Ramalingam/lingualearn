from django.apps import AppConfig


class KanConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'kan'
