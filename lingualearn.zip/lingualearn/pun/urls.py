from django.urls import path
from pun import views

urlpatterns = [
    path('pun_main',views.pun,name='Punjabi'),
    path('add_question/', views.add_question, name='add_question'),
    path('pun_quiz/', views.quiz_view, name='quiz_view'),
    path('fetch_next_question/', views.fetch_next_question, name='fetch_next_question'),
    path('submit_answer/', views.submit_answer, name='submit_answer'),
    path('pun_bot/',views.pun_bot,name="pun_bot"),
]