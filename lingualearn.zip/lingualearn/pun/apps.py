from django.apps import AppConfig


class PunConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'pun'
