from django.urls import path
from mal import views

urlpatterns = [
    path('mal_main',views.mal,name='Malayalam'),
    path('add_question/', views.add_question, name='add_question'),
    path('mal_quiz/', views.quiz_view, name='quiz_view'),
    path('fetch_next_question/', views.fetch_next_question, name='fetch_next_question'),
    path('submit_answer/', views.submit_answer, name='submit_answer'),
    path('mal_bot/',views.mal_bot,name="mal_bot"),
]