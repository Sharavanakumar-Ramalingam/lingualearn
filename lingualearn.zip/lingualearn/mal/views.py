
from django.shortcuts import render
from googletrans import Translator
from django.http import HttpResponse, JsonResponse
import requests

def mal(request):
    return render(request,"mal_main.html")


from django.http import JsonResponse, HttpResponse
from django.shortcuts import render
import requests

def mal_bot(request):
    pass
# views.py

from django.http import JsonResponse
from django.shortcuts import render, redirect
from .forms import QuestionForm, OptionForm
from .models import Question, Option

def add_question(request):
    if request.method == 'POST':
        question_form = QuestionForm(request.POST)
        option_forms = [OptionForm(request.POST, prefix=str(i)) for i in range(4)]
        if question_form.is_valid() and all([form.is_valid() for form in option_forms]):
            question = question_form.save()
            for form in option_forms:
                option = form.save(commit=False)
                option.question = question
                option.save()
            return redirect('add_question')
    else:
        question_form = QuestionForm()
        option_forms = [OptionForm(prefix=str(i)) for i in range(4)]
    return render(request, 'add_question.html', {'question_form': question_form, 'option_forms': option_forms})

def quiz_view(request):
    questions = Question.objects.all()
    return render(request, 'quiz.html', {'questions': questions})

# views.py

from django.http import JsonResponse
from django.shortcuts import render, redirect
from .forms import QuestionForm, OptionForm
from .models import Question, Option

def submit_answer(request):
    if request.method == 'POST':
        correct_answers_count = 0
        total_questions = 0
        is_correct = False  # Variable to track if the submitted answer is correct

        # Extract the submitted answer from the POST data
        answer_id = request.POST.get('answer_id')

        # Define the question_id based on your application logic
        # For example, you might get it from the POST data or session
        question_id = request.POST.get('question_id')  # Adjust this based on your code
        
        # Retrieve the correct answer from the database
        try:
            correct_option = Option.objects.get(question__id=question_id, is_correct=True)

            # Check if the submitted answer matches the correct answer
            if answer_id == str(correct_option.id):
                is_correct = True
                correct_answers_count += 1
            total_questions += 1

            # Calculate score and other logic if needed

            # Return the result as JSON response
            return JsonResponse({'is_correct': is_correct})

        except Option.DoesNotExist:
            return JsonResponse({'error': 'Question not found or invalid answer ID'})

    else:
        # Handle GET request if needed
        return HttpResponse("This page only supports POST requests.")



def generate_question_html(question):
    if question:
        question_html = f'<h3>{question.text}</h3>'
        options = question.option_set.all()
        for option in options:
            question_html += f'<input type="radio" name="question{question.id}" value="{option.id}">'
            question_html += f'<label>{option.text}</label><br>'
        return question_html
    else:
        return ''  # Return empty string if no question is provided



def fetch_next_question(request):
    if request.method == 'GET':
        next_question = Question.objects.order_by('?').first()
        question_html = generate_question_html(next_question)
        return JsonResponse({'question_html': question_html})

