from django.urls import path
from tel import views

urlpatterns = [
    path('tel_main',views.tel,name='Telugu'),
    path('add_question/', views.add_question, name='add_question'),
    path('sans_quiz/', views.quiz_view, name='quiz_view'),
    path('fetch_next_question/', views.fetch_next_question, name='fetch_next_question'),
    path('submit_answer/', views.submit_answer, name='submit_answer'),
    path('tel_bot/',views.tel_bot,name="tel_bot"),
]